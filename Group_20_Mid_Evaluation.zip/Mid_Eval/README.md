Steps to run and compile: 

To run a demo program with MESI Three Level protocol - 

Setup gem5 as per the steps available here.
cd into gem5’s directory. 
Run the below commands to build gem5 with MESI three-level protocol - 

scons defconfig build/RISCV_MESI build_opts/RISCV
scons setconfig build/RISCV_MESI RUBY_PROTOCOL_MESI_THREE_LEVEL=y 
scons build/RISCV_MESI/gem5.opt -j 7

 Place the simple_ruby.py file in gem5/configs/learning_gem5/Project/ and run the following command -
build/RISCV_MESI/gem5.opt configs/learning_gem5/Project/simple_ruby.py

 II.  To run the PARSEC benchmark on a RISCV configuration file: 
Place the riscv-parsec-benchmark.py file inside configs/example/gem5_library and run the ferret suite with the following command-

build/RISCV_MESI/gem5.opt \
configs/example/gem5_library/riscv-parsec-benchmark.py 
—-benchmark “ferret” \
—-size “simsmall”

